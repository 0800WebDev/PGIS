document.addEventListener("keydown", function(event) {
    if (event.ctrlKey && event.key === "q") {
        window.location.href = "https://www.google.com";
    }
});
